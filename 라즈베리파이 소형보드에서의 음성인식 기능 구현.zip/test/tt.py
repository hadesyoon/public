from pygame import mixer

mixer.init()
mixer.music.load('/home/pi/Desktop/test/final.mp3')
mixer.music.play()
