import librosa.display
import numpy as np
import glob
from tensorflow.keras.models import load_model
import pyaudio
import wave
import time
import ledabcde as LED
from pygame import mixer
#####GPIO
import RPi.GPIO as GPIO
import time
from sys import argv

LEDR=18
LEDY=23
LEDG=24
LEDB=16
LEDW=21
FAN=13
#basic settings
GPIO.output(LEDR, False)
GPIO.output(LEDY, False)
GPIO.output(LEDG, False)
GPIO.output(LEDB, False)
GPIO.output(LEDW, False)
GPIO.output(FAN, False)

GPIO.setwarnings (False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDR, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDY, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDG, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDB, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDW, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(FAN, GPIO.OUT)
#button
BTNW=17
GPIO.setmode(GPIO.BCM)
GPIO.setup(BTNW, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
#####
#model load

file = '/home/pi/Desktop/test/model_saved.h5'
loaded_model = load_model(file)
#result = loaded_model.score(X_test, y_test) #validation 용으로 써도 유용

print('model loaded')

#recording
CHUNK = 1024 * 8
FORMAT = pyaudio.paInt16
CHANNELS = 2
RATE = 44100
RECORD_SECONDS = 5
WAVE_OUTPUT_FILENAME = "output1.wav"

def Recording():
    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)
    time.sleep(1)
    mixer.init()
    mixer.music.load('/home/pi/Desktop/test/start.mp3')
    mixer.music.play()
    print("Start to record the audio.")

    frames = []

    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK, exception_on_overflow = False)
        frames.append(data)

    print("Recording is finished.")

    stream.stop_stream()
    stream.close()
    p.terminate()

    wf = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()
    #cut and save
    wav = glob.glob('/home/pi/Desktop/test/*.wav')
    #0~11 표준파일
    #12~16 직접 녹음파일

    y, sr = librosa.load(wav[0], sr=44100)

    #time = np.linspace(0, len(y)/sr, len(y)) # time axis
    spot = np.where(y > 0.03)
    y = y[spot[0][0]-441:spot[0][0]-441+66193]

    librosa.output.write_wav('output1.wav', y, sr)

    ####################
    #mfcc
    output = glob.glob('/home/pi/Desktop/test/*.wav')
    y, sr = librosa.load(output[0])


    min_level_db = -100
    def _normalize(S):
        return np.clip((S - min_level_db) / -min_level_db, 0, 1)



    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=20)
    mfccs = _normalize(mfccs)
    X_val = mfccs
    print(X_val.shape)
    X_val = np.reshape(X_val, (-1, 20, 65))

#decision
    print(output[0])
    answer=loaded_model.predict_classes(X_val)
    return int(answer[0])

if __name__=='__main__':
    while True:
        input_value = True
        print("Press Button to Start")
        while input_value == True:
            input_value = GPIO.input(BTNW)
            
        led=Recording()    
        while led == 1 or led == 6 or led == 7 or led == 8 or led == 9:
            mixer.init()
            mixer.music.load('/home/pi/Desktop/test/re.mp3')
            mixer.music.play()
            print("Please record again")
            time.sleep(2)
            led=Recording()
            
        action=Recording()
        while action == 0 or action == 2 or action == 3 or action == 4 or action == 5 or action == 10 or action == 11:
            mixer.init()
            mixer.music.load('/home/pi/Desktop/test/re.mp3')
            mixer.music.play()
            print("Please record again")
            time.sleep(2)
            action=Recording()
        
        print("LED: ", led)
        print("ACTION: ", action)
        mixer.init()
        mixer.music.load('/home/pi/Desktop/test/final.mp3')
        mixer.music.play()
    
        LED.lights(led, action)
        exitcommand=0
        while exitcommand != 0:
            exitcommand=input()
