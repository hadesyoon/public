import librosa.display
import numpy as np
import glob
from tensorflow.keras.models import load_model
output = glob.glob('/home/pi/Desktop/test/voice/*.wav')
file = '/home/pi/Desktop/test/model_saved.h5'
loaded_model = load_model('/home/pi/Desktop/test/model_saved.h5')
#result = loaded_model.score(X_test, y_test) #validation 용으로 써도 유용
print('model loaded')
a = 0
while a != 'exit':
    a = int(input())
    y, sr = librosa.load(output[a])
    min_level_db = -100
    def _normalize(S):
        return np.clip((S - min_level_db) / -min_level_db, 0, 1)

    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=20)
    mfccs = _normalize(mfccs)
    X_val = mfccs
    print(X_val.shape)
    X_val = np.reshape(X_val, (-1, 20, 65))

    print(output[a])
    print(loaded_model.predict_classes(X_val))
