import RPi.GPIO as GPIO
import time
from sys import argv
LEDR=18
LEDY=23
LEDG=24
LEDB=16
LEDW=21
GPIO.setwarnings (False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDR, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDY, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDG, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDB, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDW, GPIO.OUT)