import RPi.GPIO as GPIO
import time
from sys import argv
LEDR=18
LEDY=23
LEDG=24
LEDB=16
LEDW=21
FAN=13
GPIO.setwarnings (False)

GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDR, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDY, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDG, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDB, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LEDW, GPIO.OUT)
GPIO.setmode(GPIO.BCM)
GPIO.setup(FAN, GPIO.OUT)

#whichled = input("LED COLOR:")
#ledaction = input("on or off:")

def lights(whichled, ledaction):
    
    if ledaction == 1 or ledaction == 6:
        if whichled==0: #Red
            GPIO.output(LEDR, False)
        if whichled==2: #Yellow
            GPIO.output(LEDY, False)
        if whichled==4: #Green
            GPIO.output(LEDG, False)
        if whichled==5: #Blue
            GPIO.output(LEDB, False)
        if whichled==10: #White
            GPIO.output(LEDW, False)
        if whichled==3: #White
            GPIO.output(FAN, False)
            #need one more light for 11
        if whichled==11: #all for 11
            GPIO.output(LEDR, False)
            GPIO.output(LEDY, False)
            GPIO.output(LEDG, False)
            GPIO.output(LEDB, False)
            GPIO.output(LEDW, False)
            GPIO.output(FAN, False)
    if ledaction==7 or ledaction==8 or ledaction==9:
        if whichled==0: #Red
            GPIO.output(LEDR, True)
        if whichled==2: #Yellow
            GPIO.output(LEDY, True)
        if whichled==4: #Green
            GPIO.output(LEDG, True)
        if whichled==5: #Blue
            GPIO.output(LEDB, True)
        if whichled==10: #White
            GPIO.output(LEDW, True)
        if whichled==3: #White
            GPIO.output(FAN, True)
        if whichled==11:
            GPIO.output(LEDR, True)
            GPIO.output(LEDY, True)
            GPIO.output(LEDG, True)
            GPIO.output(LEDB, True)
            GPIO.output(LEDW, True)
            GPIO.output(FAN, True)
  
#GPIO.cleanup()